<div class="p-6 bg-white shadow rounded-lg">
    <div class="flex justify-end mb-4">

        <button wire:click="openModal" class="bg-blue-600 text-white px-4 py-2 rounded">+ Add Requirement</button>
    </div>

    <table class="w-full border-collapse ">
        <thead>
            <tr class="bg-gray-100">
                <th class=" px-3 py-2">ID</th>
                <th class=" px-3 py-2">Name</th>
                <th class=" px-3 py-2">Actions</th>
            </tr>
        </thead>
        <tbody>
            <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $requirements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $req): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td class="text-center px-3 py-2"><?php echo e($req->id); ?></td>
                    <td class="text-center px-3 py-2"><?php echo e($req->name); ?></td>
                    <td class="text-center px-3 py-2 space-x-2">
                        <button wire:click="openModal(<?php echo e($req->id); ?>)" class=" text-indigo-600 hover:text-indigo-900 font-semibold">Edit</button>
                        <button wire:click="delete(<?php echo e($req->id); ?>)" class="text-red-600 hover:text-red-900 font-semibold">Delete</button>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="3" class="text-center py-3">No requirements found.</td>
                </tr>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        </tbody>
    </table>

    
    <!--[if BLOCK]><![endif]--><?php if($showModal): ?>
        <div class="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 z-50">
            <div class="bg-white rounded-lg p-6 w-96">
                <h2 class="text-lg font-bold mb-4">
                    <?php echo e($isEdit ? 'Edit Requirement' : 'Add Requirement'); ?>

                </h2>

                <div class="mb-4">
                    <label class="block text-sm font-medium">Requirement Name</label>
                    <input type="text" wire:model="name" class="w-full border rounded px-3 py-2 mt-1">
                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-500 text-sm"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                </div>

                <div class="flex justify-end space-x-2">
                    <button wire:click="$set('showModal', false)" class="px-4 py-2 bg-gray-300 rounded">Cancel</button>
                    <button wire:click="save" class="px-4 py-2 bg-blue-600 text-white rounded">
                        <?php echo e($isEdit ? 'Update' : 'Save'); ?>

                    </button>
                </div>
            </div>
        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
</div>
<?php /**PATH D:\laravel\SmartAppointment\resources\views/livewire/admin/requirements.blade.php ENDPATH**/ ?>