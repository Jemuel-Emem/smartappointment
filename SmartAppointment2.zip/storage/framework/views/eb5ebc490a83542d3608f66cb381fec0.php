<div>
    <!-- Simplicity is an acquired taste. - Katharine Gerould -->
</div>
<?php /**PATH D:\laravel\SmartAppointment\resources\views\admin\requirements.blade.php ENDPATH**/ ?>