<?php $__env->startComponent('mail::message'); ?>
# New Appointment Request

Hello <?php echo e($appointment->staff->name); ?>,

You have a new appointment request:

- **Patient/User:** <?php echo e($appointment->user->name); ?>

- **Purpose:** <?php echo e($appointment->purpose_of_appointment); ?>

- **Date:** <?php echo e(\Carbon\Carbon::parse($appointment->appointment_date)->format('F d, Y')); ?>

- **Time:** <?php echo e(\Carbon\Carbon::parse($appointment->appointment_time)->format('h:i A')); ?>


Please log in to your dashboard to approve or decline this request.

<?php $__env->startComponent('mail::button', ['url' => url('/staff/appointments')]); ?>
View Appointment
<?php echo $__env->renderComponent(); ?>

Thanks,
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH D:\laravel\SmartAppointment\resources\views\emails\staff\appointment.blade.php ENDPATH**/ ?>