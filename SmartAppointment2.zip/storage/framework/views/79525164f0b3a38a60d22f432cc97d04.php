<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Appointment Update</title>
</head>
<body>
    <h2>Appointment Update</h2>
    <p>Hello <?php echo e($appointment->user->name); ?>,</p>

    <p>Your appointment with <strong><?php echo e($appointment->staff->name); ?></strong>
    on <strong><?php echo e($appointment->appointment_date); ?> at <?php echo e($appointment->appointment_time); ?></strong>
    has been <strong><?php echo e($statusMessage); ?></strong>.</p>
<?php if($requirementsList): ?>
    <p><strong>Requirements:</strong></p>
    <pre><?php echo e($requirementsList); ?></pre>
<?php endif; ?>
    <p>Thank you,<br> <?php echo e(config('SMART APPOINTMENT')); ?></p>
</body>
</html>
<?php /**PATH D:\laravel\SmartAppointment\resources\views/emails/appointment-status.blade.php ENDPATH**/ ?>