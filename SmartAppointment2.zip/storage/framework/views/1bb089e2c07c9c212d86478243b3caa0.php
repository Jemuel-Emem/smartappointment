<div class="max-w-7xl mx-auto mt-8">
    <div class="bg-white rounded-lg overflow-hidden">

        <div class="p-6">
            <?php if(session()->has('message')): ?>
                <div class="mb-4 p-3 bg-green-100 text-green-700 rounded">
                    <?php echo e(session('message')); ?>

                </div>
            <?php endif; ?>

            <?php if($appointments->isEmpty()): ?>
                <p class="text-gray-500">You have no appointments yet.</p>
            <?php else: ?>
                <table class="w-full border-collapse border border-gray-200">
                    <thead class="bg-gray-100">
                        <tr>
                            <th class="border border-gray-200 px-4 py-2">Date</th>
                            <th class="border border-gray-200 px-4 py-2">Time</th>
                            <th class="border border-gray-200 px-4 py-2">Purpose</th>
                            <th class="border border-gray-200 px-4 py-2">Status</th>

                            <th class="border border-gray-200 px-4 py-2">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $appointments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $appointment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                         <tr>
    <td class="border px-4 py-2"><?php echo e(\Carbon\Carbon::parse($appointment->appointment_date)->format('M d, Y')); ?></td>
    <td class="border px-4 py-2"><?php echo e(\Carbon\Carbon::parse($appointment->appointment_time)->format('h:i A')); ?></td>
    <td class="border px-4 py-2"><?php echo e($appointment->purpose_of_appointment); ?></td>
    <td class="border px-4 py-2 text-center">
        <?php if($appointment->status === 'approved'): ?>
            <span class="bg-green-100 text-green-700 px-3 py-1 rounded-full text-sm">Approved</span>
        <?php elseif($appointment->status === 'pending'): ?>
            <span class="bg-yellow-100 text-yellow-700 px-3 py-1 rounded-full text-sm">Pending</span>
        <?php elseif($appointment->status === 'declined'): ?>
            <span class="bg-red-100 text-red-700 px-3 py-1 rounded-full text-sm">Declined</span>
        <?php elseif($appointment->status === 'cancelled'): ?>
            <span class="bg-gray-200 text-gray-700 px-3 py-1 rounded-full text-sm">Cancelled</span>
        <?php elseif($appointment->status === 'completed'): ?>
            <span class="bg-blue-100 text-blue-700 px-3 py-1 rounded-full text-sm">Completed</span>
        <?php endif; ?>
    </td>
   <td class="border px-4 py-2 space-x-2 flex justify-center">
    <?php if($appointment->status === 'pending' || $appointment->status === 'approved'): ?>
        <button wire:click="cancel(<?php echo e($appointment->id); ?>)"
            class="px-3 py-1 bg-red-500 text-white rounded hover:bg-red-600">
            Cancel
        </button>
        <button wire:click="openReschedule(<?php echo e($appointment->id); ?>)"
            class="px-3 py-1 bg-blue-500 text-white rounded hover:bg-blue-600">
            Reschedule
        </button>
<?php elseif($appointment->status === 'completed' && !$appointment->rated): ?>
    <button wire:click="openRatingModal(<?php echo e($appointment->id); ?>)"
        class="px-3 py-1 bg-emerald-500 text-white rounded hover:bg-emerald-600">
        Rate Now
    </button>
<?php elseif($appointment->status === 'completed' && $appointment->rated): ?>
    <span class="text-gray-400 italic">No actions</span>

    <?php endif; ?>
</td>

</tr>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>
    </div>

<?php if($showRatingModal): ?>
    <div class="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 z-50">
        <div class="bg-white rounded-lg shadow-lg w-96 p-6">
            <h2 class="text-lg font-bold mb-4">Rate Staff</h2>

            <div class="mb-4">
                <label class="block text-sm font-medium text-gray-700">Your Rating (1-5)</label>
                <select wire:model="rating" class="w-full border rounded px-3 py-2 mt-1">
                    <option value="">Select</option>
                    <option value="1">1 - Very Poor</option>
                    <option value="2">2 - Poor</option>
                    <option value="3">3 - Fair</option>
                    <option value="4">4 - Good</option>
                    <option value="5">5 - Excellent</option>
                </select>
            </div>

             <div class="mb-4">
                <label class="block text-sm font-medium text-gray-700">Comment (optional)</label>
                <textarea wire:model="comment" rows="3"
                    class="w-full border rounded px-3 py-2 mt-1"
                    placeholder="Write your feedback here..."></textarea>
            </div>

            <div class="flex justify-end space-x-2">
                <button wire:click="$set('showRatingModal', false)"
                    class="px-4 py-2 bg-gray-300 rounded hover:bg-gray-400">Cancel</button>
                <button wire:click="submitRating"
                    class="px-4 py-2 bg-emerald-600 text-white rounded hover:bg-emerald-700">Submit</button>
            </div>
        </div>
    </div>
<?php endif; ?>

    
    <?php if($showRescheduleModal): ?>
        <div class="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 z-50">
            <div class="bg-white rounded-lg shadow-lg w-96 p-6">
                <h2 class="text-lg font-bold mb-4">Reschedule Appointment</h2>

                <div class="mb-4">
                    <label class="block text-sm font-medium text-gray-700">New Date</label>
                    <input type="date" wire:model="rescheduleDate" class="w-full border rounded px-3 py-2 mt-1">
                </div>

                <div class="mb-4">
                    <label class="block text-sm font-medium text-gray-700">New Time</label>
                    <input type="time" wire:model="rescheduleTime" class="w-full border rounded px-3 py-2 mt-1">
                </div>

                <div class="flex justify-end space-x-2">
                    <button wire:click="$set('showRescheduleModal', false)" class="px-4 py-2 bg-gray-300 rounded hover:bg-gray-400">Cancel</button>
                    <button wire:click="reschedule" class="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700">Save</button>
                </div>
            </div>
        </div>
    <?php endif; ?>
</div><?php /**PATH D:\laravel\SmartAppointment\resources\views\livewire\user\status.blade.php ENDPATH**/ ?>