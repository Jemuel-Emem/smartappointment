<x-user--layout>
    <div>

        <div class="  ">
            <livewire:user.appointment/>
        </div>

    </div>
</x-user--layout>
