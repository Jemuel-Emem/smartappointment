<x-user--layout>
    <div>

        <div class="  ">
            <livewire:user.profile/>
        </div>

    </div>
</x-user--layout>
