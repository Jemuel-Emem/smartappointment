<x-admin--layout>
    <div>

        <div class="  ">
            <livewire:admin.requirements/>
        </div>

    </div>
</x-admin--layout>
