<x-admin--layout>
    <div>

        <div class="  ">
            <livewire:admin.services/>
        </div>

    </div>
</x-admin--layout>
