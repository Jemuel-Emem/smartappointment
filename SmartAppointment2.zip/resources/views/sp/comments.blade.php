<x-super--layout>
    <div>

        <div class="  ">
            <livewire:sp.comments/>
        </div>

    </div>
</x-super--layout>
