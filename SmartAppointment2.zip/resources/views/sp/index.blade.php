<x-super--layout>
    <div>

        <div class="  ">
            <livewire:sp.index/>
        </div>

    </div>
</x-super--layout>
