<div class=" mx-auto bg-white shadow-lg rounded-lg p-6">
    <h2 class="text-2xl font-bold mb-4 text-blue-600">Create Announcement</h2>

    <?php if(session('success')): ?>
        <div class="p-3 mb-4 text-green-700 bg-green-100 border border-green-200 rounded-lg">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <form wire:submit.prevent="createAnnouncement" class="space-y-4">
        <div>
            <label class="block text-gray-700 font-medium">Title</label>
            <input type="text" wire:model="title" class="w-full border rounded-lg px-4 py-2 mt-1 focus:ring focus:border-blue-400">
            <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-500 text-sm"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div>
            <label class="block text-gray-700 font-medium">Message</label>
            <textarea wire:model="message" rows="4" class="w-full border rounded-lg px-4 py-2 mt-1 focus:ring focus:border-blue-400"></textarea>
            <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-500 text-sm"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div>
            <label class="block text-gray-700 font-medium">Audience</label>
            <select wire:model="audience" class="w-full border rounded-lg px-4 py-2 mt-1 focus:ring focus:border-blue-400">
                <option value="departments">Departments Only</option>
                <option value="users">Users Only</option>
                <option value="both">Both</option>
                <option value="specific_department">Specific Department</option>
            </select>
            <?php $__errorArgs = ['audience'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-500 text-sm"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <?php if($audience === 'specific_department'): ?>
            <div>
                <label class="block text-gray-700 font-medium">Select Department</label>
                <select wire:model="department_id" class="w-full border rounded-lg px-4 py-2 mt-1 focus:ring focus:border-blue-400">
                    <option value="">-- Choose Department --</option>
                    <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dept): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($dept->id); ?>"><?php echo e($dept->department_name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php $__errorArgs = ['department_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-500 text-sm"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        <?php endif; ?>

        <div class="pt-3">
            <button type="submit" class="bg-blue-600 hover:bg-blue-700 text-white font-semibold px-4 py-2 rounded-lg">
                Post Announcement
            </button>
        </div>
    </form>

    <hr class="my-6">

    <h3 class="text-xl font-semibold mb-3 text-gray-700">Recent Announcements</h3>
    <div class="space-y-3">
        <?php $__currentLoopData = $announcements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="border rounded-lg p-3 bg-gray-50">
                <h4 class="font-semibold text-blue-700"><?php echo e($a->title); ?></h4>
                <p class="text-gray-700 text-sm mt-1"><?php echo e($a->message); ?></p>
                <p class="text-xs text-gray-500 mt-2">
                    For:
                    <span class="font-medium">
                        <?php if($a->audience === 'departments'): ?> Departments Only
                        <?php elseif($a->audience === 'users'): ?> Users Only
                        <?php elseif($a->audience === 'both'): ?> Both
                        <?php elseif($a->audience === 'specific_department'): ?>
                            <?php echo e($a->department->department_name ?? 'N/A'); ?>

                        <?php endif; ?>
                    </span>
                    • <?php echo e($a->created_at->diffForHumans()); ?>

                </p>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div><?php /**PATH D:\laravel\SmartAppointment\resources\views\livewire\sp\announcement.blade.php ENDPATH**/ ?>