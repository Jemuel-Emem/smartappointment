<?php if (isset($component)) { $__componentOriginal2347ae46c6307a1df37c6e547e9dfae2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2347ae46c6307a1df37c6e547e9dfae2 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin--layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin--layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div>

        <div class="  ">
            <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('admin.requirements', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-276934870-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
        </div>

    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2347ae46c6307a1df37c6e547e9dfae2)): ?>
<?php $attributes = $__attributesOriginal2347ae46c6307a1df37c6e547e9dfae2; ?>
<?php unset($__attributesOriginal2347ae46c6307a1df37c6e547e9dfae2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2347ae46c6307a1df37c6e547e9dfae2)): ?>
<?php $component = $__componentOriginal2347ae46c6307a1df37c6e547e9dfae2; ?>
<?php unset($__componentOriginal2347ae46c6307a1df37c6e547e9dfae2); ?>
<?php endif; ?>
<?php /**PATH D:\laravel\SmartAppointment\resources\views\admin\requirements.blade.php ENDPATH**/ ?>