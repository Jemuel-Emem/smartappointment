<?php if (isset($component)) { $__componentOriginal34cd45e6305ee609fda8cb09a52c7745 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal34cd45e6305ee609fda8cb09a52c7745 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.super--layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('super--layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div>

        <div class="  ">
            <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('sp.announcement', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-3749401282-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
        </div>

    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal34cd45e6305ee609fda8cb09a52c7745)): ?>
<?php $attributes = $__attributesOriginal34cd45e6305ee609fda8cb09a52c7745; ?>
<?php unset($__attributesOriginal34cd45e6305ee609fda8cb09a52c7745); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal34cd45e6305ee609fda8cb09a52c7745)): ?>
<?php $component = $__componentOriginal34cd45e6305ee609fda8cb09a52c7745; ?>
<?php unset($__componentOriginal34cd45e6305ee609fda8cb09a52c7745); ?>
<?php endif; ?>
<?php /**PATH D:\laravel\SmartAppointment\resources\views\sp\announcement.blade.php ENDPATH**/ ?>