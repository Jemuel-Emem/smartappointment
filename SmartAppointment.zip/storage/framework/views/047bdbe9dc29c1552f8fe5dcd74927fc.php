<?php if (isset($component)) { $__componentOriginal48671edc72cee3435d82d693b6406a4d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal48671edc72cee3435d82d693b6406a4d = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.user--layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('user--layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div>

        <div class="  ">
            <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('user.announcement', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-2320999923-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
        </div>

    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal48671edc72cee3435d82d693b6406a4d)): ?>
<?php $attributes = $__attributesOriginal48671edc72cee3435d82d693b6406a4d; ?>
<?php unset($__attributesOriginal48671edc72cee3435d82d693b6406a4d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal48671edc72cee3435d82d693b6406a4d)): ?>
<?php $component = $__componentOriginal48671edc72cee3435d82d693b6406a4d; ?>
<?php unset($__componentOriginal48671edc72cee3435d82d693b6406a4d); ?>
<?php endif; ?>
<?php /**PATH D:\laravel\SmartAppointment\resources\views\user\announcement.blade.php ENDPATH**/ ?>