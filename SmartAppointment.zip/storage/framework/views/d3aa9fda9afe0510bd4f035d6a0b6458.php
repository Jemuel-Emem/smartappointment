<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title>SmartAppoint </title>

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=figtree:400,500,600&display=swap" rel="stylesheet" />

    <!-- Scripts -->
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>
<body class="font-sans antialiased bg-gradient-to-br from-blue-100 via-white to-pink-100 min-h-screen">

    <div class="min-h-screen flex flex-col justify-center items-center px-4">
        <!-- Logo + Title -->
        <div class="flex items-center gap-3 mb-6">
            <img class="w-16 h-16" src="<?php echo e(asset('images/schedule.png')); ?>" alt="App Logo">
            <h1 class="text-3xl font-bold text-blue-700">SmartAppoint</h1>
        </div>

        <!-- Card Container -->
        <div class="w-full max-w-md bg-white shadow-xl rounded-xl px-8 py-6">
            <?php echo e($slot); ?>

        </div>
    </div>

</body>
</html>
<?php /**PATH D:\laravel\SmartAppointment\resources\views\layouts\guest.blade.php ENDPATH**/ ?>