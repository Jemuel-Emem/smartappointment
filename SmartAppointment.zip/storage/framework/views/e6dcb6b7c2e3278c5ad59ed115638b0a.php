<div class=" mx-auto bg-white shadow rounded-lg p-6">
    <h2 class="text-2xl font-semibold text-blue-600 mb-4">Department Announcements</h2>

    <?php if($announcements->isEmpty()): ?>
        <p class="text-gray-500">No announcements available for your department.</p>
    <?php else: ?>
        <div class="space-y-4">
            <?php $__currentLoopData = $announcements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="border border-gray-200 rounded-lg p-4 bg-gray-50">
                    <h3 class="font-semibold text-lg text-blue-700"><?php echo e($a->title); ?></h3>
                    <p class="text-gray-700 mt-1"><?php echo e($a->message); ?></p>

                    <p class="text-xs text-gray-500 mt-2">
                        For:
                        <span class="font-medium">
                            <?php if($a->audience === 'departments'): ?> Departments Only
                            <?php elseif($a->audience === 'users'): ?> Users Only
                            <?php elseif($a->audience === 'both'): ?> Both
                            <?php elseif($a->audience === 'specific_department'): ?>
                                <?php echo e($a->department->department_name ?? 'N/A'); ?>

                            <?php endif; ?>
                        </span>
                        • <?php echo e($a->created_at->diffForHumans()); ?>

                    </p>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endif; ?>
</div><?php /**PATH D:\laravel\SmartAppointment\resources\views\livewire\admin\announcement.blade.php ENDPATH**/ ?>