<div class="max-w-7xl mt-2 mx-auto bg-gradient-to-br from-blue-50 to-white p-8 rounded-2xl shadow-lg border border-blue-100">

    
    <div class="mb-4 flex justify-end gap-2">
        <button type="button" wire:click="$set('language', 'en')"
            class="px-4 py-2 rounded-lg border
            <?php echo e($language === 'en' ? 'bg-blue-600 text-white border-blue-600' : 'bg-white text-gray-700 border-gray-300'); ?>">
            English
        </button>
        <button type="button" wire:click="$set('language', 'tl')"
            class="px-4 py-2 rounded-lg border
            <?php echo e($language === 'tl' ? 'bg-blue-600 text-white border-blue-600' : 'bg-white text-gray-700 border-gray-300'); ?>">
            Tagalog
        </button>
        <button type="button" wire:click="$set('language', 'bs')"
            class="px-4 py-2 rounded-lg border
            <?php echo e($language === 'bs' ? 'bg-blue-600 text-white border-blue-600' : 'bg-white text-gray-700 border-gray-300'); ?>">
            Bisaya
        </button>
    </div>

    <h2 class="text-3xl font-bold mb-6 text-center text-blue-700">
        <?php echo e($translations[$language]['book_title']); ?>

    </h2>

    
    <?php if(session('success')): ?>
        <div class="mb-6 p-4 text-green-800 bg-green-100 border border-green-200 rounded-lg text-sm">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>
    <?php if(session('error')): ?>
        <div class="mb-6 p-4 text-red-800 bg-red-100 border border-red-200 rounded-lg text-sm">
            <?php echo e(session('error')); ?>

        </div>
    <?php endif; ?>

    
    <div class="mb-5">
        <label class="block text-gray-700 font-semibold mb-2"><?php echo e($translations[$language]['select_department']); ?></label>
        <select wire:model="department_id" class="w-full border border-gray-300 rounded-lg px-4 py-2">
            <option value=""><?php echo e($translations[$language]['choose_department']); ?></option>
            <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dept): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($dept->id); ?>"><?php echo e($dept->department_name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <?php $__errorArgs = ['department_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    
    <div class="mb-5">
        <label class="block text-gray-700 font-semibold mb-2"><?php echo e($translations[$language]['purpose_label']); ?></label>
   <input type="text" wire:model.live="purpose_of_appointment"
       placeholder="<?php echo e($translations[$language]['purpose_placeholder']); ?>"
       class="w-full border border-gray-300 rounded-lg px-4 py-2">
        <?php $__errorArgs = ['purpose_of_appointment'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        
        <div wire:loading wire:target="purpose_of_appointment" class="mt-2 text-blue-600">
            Searching for staff...
        </div>
    </div>

    
    <?php if($showStaffList): ?>
        <div class="mb-6 bg-blue-50 p-4 rounded-lg">
            <h3 class="font-semibold text-blue-800 mb-3"><?php echo e($translations[$language]['recommended']); ?></h3>

            <?php $__errorArgs = ['selectedStaffId'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-red-500 text-sm mb-3 font-medium">⚠️ <?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                <?php $__empty_1 = true; $__currentLoopData = $suggestedStaff; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $staff): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="p-4 border rounded-lg shadow-md bg-white hover:shadow-lg transition-all
                        <?php echo e($selectedStaffId == $staff->id ? 'border-2 border-blue-500 bg-blue-50' : 'border-gray-200'); ?>">
                        <h3 class="text-lg font-semibold text-gray-800"><?php echo e($staff->name); ?></h3>
                        <p class="text-gray-600"><span class="font-medium">Speciality:</span> <?php echo e($staff->speciality); ?></p>
                        <p class="text-gray-600"><span class="font-medium">Service:</span> <?php echo e($staff->service_type); ?></p>
                       <p class="text-gray-600">
    <span class="font-medium">Availability:</span>
    <?php echo e($staff->availability ? 'Available' : 'Not Available'); ?>

</p>

                        <div class="mt-3 flex items-center justify-between">
                          <div class="flex items-center">
<?php
    $avgRating = $staff->ratings_avg_rating ?? 0;
    $fullStars = floor($avgRating);
    $halfStar = ($avgRating - $fullStars) >= 0.5;
    $emptyStars = 5 - $fullStars - ($halfStar ? 1 : 0);
?>




<div>
    Average Rating: <?php echo e($staff->ratings_avg_rating ? number_format($staff->ratings_avg_rating, 1) : 'No ratings yet'); ?>

</div>

</div>

                            <button wire:click="selectStaff(<?php echo e($staff->id); ?>)"
                                    class="px-3 py-1 bg-blue-500 hover:bg-blue-600 text-white rounded text-sm">
                                <?php echo e($selectedStaffId == $staff->id ? 'Selected' : 'Choose'); ?>

                            </button>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="col-span-full p-4 text-center bg-yellow-50 rounded-lg">
                        <p class="text-yellow-700">No specialists found matching your purpose. Try different keywords.</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    <?php endif; ?>


    <div class="mb-6" wire:ignore>
        <label class="block text-gray-700 font-semibold mb-2"><?php echo e($translations[$language]['appointment_date']); ?></label>
     <div id="appointment_date_picker" class="w-full bg-white rounded-lg "></div>

        <?php $__errorArgs = ['appointment_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>


    <div class="mb-6">
        <label class="block text-gray-700 font-semibold mb-2"><?php echo e($translations[$language]['appointment_time']); ?></label>
    <select wire:model="appointment_time" class="w-full border border-gray-300 rounded-lg px-4 py-2">
    <option value=""><?php echo e($translations[$language]['select_time']); ?></option>

    <?php
        $times = [
            '08:30', '09:00', '09:30', '10:00', '10:30', '11:00',
            '13:00', '13:30', '14:00', '14:30', '15:00', '15:30',
            '16:00', '16:30', '17:00'
        ];
    ?>

    <?php $__currentLoopData = $times; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $time): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($time); ?>"><?php echo e(date('g:i A', strtotime($time))); ?></option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>

        <?php $__errorArgs = ['appointment_time'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    
    <button wire:click="submit"
            class="w-full bg-gradient-to-r from-blue-600 to-blue-700 text-white font-semibold py-3 px-6 rounded-lg">
        <?php echo e($translations[$language]['submit']); ?>

    </button>

    
    <script>
      document.addEventListener('DOMContentLoaded', function () {
    flatpickr("#appointment_date_picker", {
        inline: true,   // always show calendar
        dateFormat: "Y-m-d",
        minDate: "today",
        onChange: function (selectedDates, dateStr) {
            Livewire.find(
                document.querySelector('[wire\\:id]').getAttribute('wire:id')
            ).set('appointment_date', dateStr);
        }
    });
});

    </script>
</div><?php /**PATH D:\laravel\SmartAppointment\resources\views\livewire\user\appointment.blade.php ENDPATH**/ ?>