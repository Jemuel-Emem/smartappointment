<div class="p-6 bg-white shadow rounded-lg">
    <!--[if BLOCK]><![endif]--><?php if($appointments->count()): ?>
        <div class="overflow-x-auto">
            <table class="min-w-full divide-y divide-gray-200 rounded-lg overflow-hidden shadow-sm">
                <thead class="bg-gray-50">
                    <tr>
                        <th class="px-6 py-3 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider">Name</th>
                        <th class="px-6 py-3 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider">Assign Staff</th>
                        <th class="px-6 py-3 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider">Purpose</th>
                        <th class="px-6 py-3 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider">Date</th>
                        <th class="px-6 py-3 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider">Time</th>
                        <th class="px-6 py-3 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider">Status</th>
                        <th class="px-6 py-3 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider">Action</th>
                    </tr>
                </thead>
                <tbody class="bg-white divide-y divide-gray-200">
                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $appointments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $appointment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="hover:bg-gray-50 transition-colors">
                            <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900"><?php echo e($appointment->user->name ?? 'N/A'); ?></td>

                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-700"><?php echo e($appointment->staff->name ?? 'N/A'); ?></td>
                            <td class="px-6 py-4 text-sm text-gray-700"><?php echo e($appointment->purpose_of_appointment); ?></td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-700"><?php echo e(\Carbon\Carbon::parse($appointment->appointment_date)->format('M d, Y')); ?></td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-700"><?php echo e(\Carbon\Carbon::parse($appointment->appointment_time)->format('h:i A')); ?></td>
                            <td class="px-6 py-4 text-sm text-gray-700 capitalize"><?php echo e($appointment->status); ?></td>
                           <td class="px-6 py-4 text-sm text-gray-700 flex gap-2">
  <!--[if BLOCK]><![endif]--><?php if($appointment->status === 'pending'): ?>
    <button wire:click="approve(<?php echo e($appointment->id); ?>)"
        class="px-3 py-1 bg-green-500 text-white text-xs rounded hover:bg-green-600">
        Approve
    </button>
    <button wire:click="decline(<?php echo e($appointment->id); ?>)"
        class="px-3 py-1 bg-red-500 text-white text-xs rounded hover:bg-red-600">
        Decline
    </button>
<?php elseif($appointment->status === 'approved'): ?>
    <button wire:click="complete(<?php echo e($appointment->id); ?>)"
        class="px-3 py-1 bg-blue-500 text-white text-xs rounded hover:bg-blue-600">
        Completed
    </button>
    <button wire:click="openReschedule(<?php echo e($appointment->id); ?>)"
        class="px-3 py-1 bg-yellow-500 text-white text-xs rounded hover:bg-yellow-600">
        Reschedule
    </button>
<?php else: ?>
    <span class="text-gray-400 italic">No actions</span>
<?php endif; ?><!--[if ENDBLOCK]><![endif]-->

</td>

                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                </tbody>
            </table>
        </div>
    <?php else: ?>
        <p class="text-gray-500 italic">No appointments found.</p>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->


    <!--[if BLOCK]><![endif]--><?php if($showRescheduleModal): ?>
<div class="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 z-50">
    <div class="bg-white rounded-lg shadow-lg p-6 w-full max-w-md">
        <h2 class="text-lg font-bold mb-4">Reschedule Appointment</h2>

        <div class="mb-4">
            <label class="block text-gray-700 mb-2">New Date</label>
            <input type="date" wire:model="new_date" class="w-full border rounded px-3 py-2">
            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['new_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
        </div>

        <div class="mb-4">
            <label class="block text-gray-700 mb-2">New Time</label>
            <input type="time" wire:model="new_time" class="w-full border rounded px-3 py-2">
            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['new_time'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
        </div>

        <div class="flex justify-end gap-2">
            <button wire:click="$set('showRescheduleModal', false)"
                class="px-4 py-2 bg-gray-300 rounded hover:bg-gray-400">
                Cancel
            </button>
            <button wire:click="saveReschedule"
                class="px-4 py-2 bg-yellow-500 text-white rounded hover:bg-yellow-600">
                Save Changes
            </button>
        </div>
    </div>
</div>
<?php endif; ?><!--[if ENDBLOCK]><![endif]-->

</div>
<?php /**PATH D:\laravel\SmartAppointment\resources\views/livewire/admin/appointments.blade.php ENDPATH**/ ?>