<div class="bg-white p-4 rounded shadow">
    <h2 class="text-lg font-semibold mb-3">⭐ Ratings & Feedback Summary</h2>

    <!-- Summary -->
    <div class="mb-4">
        <p><strong>Average Rating:</strong> <?php echo e(number_format($summary->avg_rating, 1) ?? 'N/A'); ?> / 5</p>
        <p><strong>Total Feedbacks:</strong> <?php echo e($summary->total_feedbacks); ?></p>
    </div>

    <!-- Comments -->
    <h3 class="font-semibold mb-2">💬 Latest Comments</h3>
    <ul class="space-y-3">
        <?php $__empty_1 = true; $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <li class="border p-2 rounded">
                <p class="text-sm text-gray-600">
                    <strong><?php echo e($comment->user->name ?? 'Anonymous'); ?></strong>
                    on <em><?php echo e($comment->staff->name ?? 'Unknown Staff'); ?></em>
                </p>
                <p class="text-yellow-500">Rating: ⭐ <?php echo e($comment->rating); ?></p>
                <p class="text-gray-800"><?php echo e($comment->comment); ?></p>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p class="text-gray-500">No feedback yet.</p>
        <?php endif; ?>
    </ul>
</div><?php /**PATH D:\laravel\SmartAppointment\resources\views\livewire\sp\comments.blade.php ENDPATH**/ ?>