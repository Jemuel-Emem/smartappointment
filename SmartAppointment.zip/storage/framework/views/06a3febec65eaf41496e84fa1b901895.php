<div class="p-6">
    <!-- Add Staff Button -->
    <div class="flex justify-end">
        <button wire:click="openModal" class="bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded w-64">
            Add Staff
        </button>
    </div>

    <?php if(session()->has('message')): ?>
        <div class="mt-2 mb-4 rounded-md bg-green-50 border border-green-200 p-3 text-green-800">
            <?php echo e(session('message')); ?>

        </div>
    <?php endif; ?>
    <?php if(session()->has('error')): ?>
        <div class="mt-2 mb-4 rounded-md bg-red-50 border border-red-200 p-3 text-red-800">
            <?php echo e(session('error')); ?>

        </div>
    <?php endif; ?>

    <div class="mt-6 overflow-x-auto">
        <table class="min-w-full divide-y divide-gray-200">
            <thead class="bg-gray-50">
                <tr>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Name</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Address</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Phone</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Service</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Speciality</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Availability</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Actions</th>
                </tr>
            </thead>
            <tbody class="bg-white divide-y divide-gray-200">
                <?php $__empty_1 = true; $__currentLoopData = $staffList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $staff): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr class="hover:bg-gray-100">
                        <td class="px-6 py-4 text-sm font-medium text-gray-900"><?php echo e($staff->name); ?></td>
                        <td class="px-6 py-4 text-sm text-gray-700"><?php echo e($staff->address); ?></td>
                        <td class="px-6 py-4 text-sm text-gray-700"><?php echo e($staff->phone_number); ?></td>
                        <td class="px-6 py-4 text-sm text-gray-700"><?php echo e($staff->service_type); ?></td>
                        <td class="px-6 py-4 text-sm text-gray-700"><?php echo e($staff->speciality); ?></td>

                        <!-- Availability -->
                        <td class="px-6 py-4 text-sm">
                            <?php if($staff->availability): ?>
                                <button wire:click="toggleAvailability(<?php echo e($staff->id); ?>)"
                                    class="px-3 py-1 bg-green-500 text-white rounded hover:bg-green-600">
                                    Available
                                </button>
                            <?php else: ?>
                                <button wire:click="toggleAvailability(<?php echo e($staff->id); ?>)"
                                    class="px-3 py-1 bg-red-500 text-white rounded hover:bg-red-600">
                                    Not Available
                                </button>
                            <?php endif; ?>
                        </td>

                        <!-- Actions -->
                        <td class="px-6 py-4 text-sm text-gray-700 space-x-2">
                            <button wire:click="editStaff(<?php echo e($staff->id); ?>)"
                                class="text-indigo-600 hover:text-indigo-900 font-semibold">Edit</button>
                            <button wire:click="confirmDelete(<?php echo e($staff->id); ?>)"
                                class="text-red-600 hover:text-red-900 font-semibold">Delete</button>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="7" class="px-6 py-4 text-center text-sm text-gray-500">No staff found</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <!-- Add/Edit Modal -->
    <?php if($showModal): ?>
        <div class="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 z-50">
            <div class="bg-white rounded-lg shadow-lg p-6 w-96">
                <h2 class="text-lg font-bold mb-4">
                    <?php echo e($staffIdBeingEdited ? 'Edit Staff' : 'Add Staff'); ?>

                </h2>

                <div class="mb-3">
                    <label class="block text-sm font-medium">Name</label>
                    <input type="text" wire:model="name" class="w-full border rounded p-2">
                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-500 text-sm"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="mb-3">
                    <label class="block text-sm font-medium">Address</label>
                    <input type="text" wire:model="address" class="w-full border rounded p-2">
                    <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-500 text-sm"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="mb-3">
                    <label class="block text-sm font-medium">Phone Number</label>
                    <input type="text" wire:model="phone_number" class="w-full border rounded p-2">
                    <?php $__errorArgs = ['phone_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-500 text-sm"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="mb-3">
                    <label class="block text-sm font-medium">Service</label>
                    <input type="text" wire:model="service" class="w-full border rounded p-2">
                    <?php $__errorArgs = ['service'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-500 text-sm"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="mb-3">
                    <label class="block text-sm font-medium">Speciality</label>
                    <input type="text" wire:model="speciality" class="w-full border rounded p-2">
                    <?php $__errorArgs = ['speciality'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-500 text-sm"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="mb-3">
                    <label class="block text-sm font-medium">Requirement Name</label>
                    <input type="text" wire:model="requirement" class="w-full border rounded p-2">
                    <?php $__errorArgs = ['requirement'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-500 text-sm"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="flex justify-end">
                    <button wire:click="$set('showModal', false)" class="px-4 py-2 border rounded mr-2">Cancel</button>
                    <button wire:click="saveStaff" class="px-4 py-2 bg-blue-500 text-white rounded">Save</button>
                </div>
            </div>
        </div>
    <?php endif; ?>


    <?php if($confirmingDelete): ?>
        <div class="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 z-50">
            <div class="bg-white rounded-lg shadow-lg p-6 w-96 text-center">
                <h2 class="text-lg font-bold mb-3 text-red-600">Confirm Delete</h2>
                <p class="text-gray-700 mb-6">Are you sure you want to delete this staff member?</p>
                <div class="flex justify-center gap-4">
                    <button wire:click="$set('confirmingDelete', false)" class="px-4 py-2 border rounded">Cancel</button>
                    <button wire:click="deleteStaffConfirmed" class="px-4 py-2 bg-red-500 text-white rounded">Yes, Delete</button>
                </div>
            </div>
        </div>
    <?php endif; ?>
</div><?php /**PATH D:\laravel\SmartAppointment\resources\views\livewire\admin\staffs.blade.php ENDPATH**/ ?>