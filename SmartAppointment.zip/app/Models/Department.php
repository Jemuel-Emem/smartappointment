<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Department extends Model
{
protected $fillable = ['user_id', 'department_name', 'service_type'];

    public function user()
    {
        return $this->belongsTo(User::class);
    }

      public function staff()
    {
        return $this->hasMany(Staff::class);
    }

    public function appointments()
    {
        return $this->hasMany(Appointment::class, 'department_id', 'user_id');
    }
}
