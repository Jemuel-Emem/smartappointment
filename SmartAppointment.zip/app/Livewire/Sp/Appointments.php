<?php

namespace App\Livewire\Sp;

use Livewire\Component;

class Appointments extends Component
{
    public function render()
    {
        return view('livewire.sp.appointments');
    }
}
