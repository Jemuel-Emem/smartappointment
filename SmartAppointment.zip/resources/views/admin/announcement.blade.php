<x-admin--layout>
    <div>

        <div class="  ">
            <livewire:admin.announcement/>
        </div>

    </div>
</x-admin--layout>
