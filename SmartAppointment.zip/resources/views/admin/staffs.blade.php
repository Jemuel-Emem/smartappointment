<x-admin--layout>
    <div>

        <div class="  ">
            <livewire:admin.staffs/>
        </div>

    </div>
</x-admin--layout>
