<x-super--layout>
    <div>

        <div class="  ">
            <livewire:sp.department/>
        </div>

    </div>
</x-super--layout>
