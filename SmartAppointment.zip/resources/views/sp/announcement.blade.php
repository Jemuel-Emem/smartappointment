<x-super--layout>
    <div>

        <div class="  ">
            <livewire:sp.announcement/>
        </div>

    </div>
</x-super--layout>
