<x-user--layout>
    <div>

        <div class="  ">
            <livewire:user.index/>
        </div>

    </div>
</x-user--layout>
