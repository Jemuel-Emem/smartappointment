<x-user--layout>
    <div>

        <div class="  ">
            <livewire:user.announcement/>
        </div>

    </div>
</x-user--layout>
